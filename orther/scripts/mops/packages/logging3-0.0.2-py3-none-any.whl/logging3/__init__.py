name = "logging3"

from .handlers import TimedCompressedRotatingFileHandler
